// Configuración de Firebase (rellena con tu proyecto real)
window.FIREBASE_CONFIG = window.FIREBASE_CONFIG || {
  apiKey: "REEMPLAZA_AQUI",
  authDomain: "REEMPLAZA_AQUI.firebaseapp.com",
  projectId: "REEMPLAZA_AQUI",
};

// Clave SOLO para abrir Auditoría
window.AUDIT_KEY = "26238915";
